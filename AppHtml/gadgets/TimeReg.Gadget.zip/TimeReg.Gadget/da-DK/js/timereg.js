$(document).ready(function(){
    $('#username').click(function(){
        $('#username').val('');
    });
    $('#password').focus(function(){
        $('#password').val('');
    });
    $('#login_button').click(function(){
        host = getHost();
        urlStr  = host
                + '?module=User&view=ajax_login'
                + '&username=' + $('#username').val()
                + '&password=' + $('#password').val()
                + '&' + new String (Math.random()).substring (2, 11)
                + '&format=json&callback=?'
                ;
  //$('#username').val(urlStr);
        $.ajax({url: urlStr,
                cache: true,
                dataType: "jsonp",
                success: function(data){
                  $('#username').val(data.user_id);
                  if (data.user_id > 0) {
                                
                    $('#username').val(''); //'OK: ' + data.user_id);
                    $('#login').hide();
                    $('#userid').val(data.user_id);
                    getListOfProjects(data.user_id);
                    getActive();
                    $('#register').show();
                  } else {
                    $('#username').val('Fail: ' + data.user_id);
                  }
                }
        });
    });
    
    function getListOfProjects(userId) {
        host = getHost();
        urlStr  = host
                + '?module=Project&view=project_list'
                + '&userid=' + $('#userid').val()
                + '&' + new String (Math.random()).substring (2, 11)
                + '&format=json&callback=?';
                ;
  
        $.ajax({url: urlStr,
                cache: true,
                dataType: "jsonp",
                success: function(projectList){
           	        //projList = projectList.split(',');
        
           	        i = 0;
           	        projCont = '';
           	        //while (projList[i].project_id != undefined) {
           	        for (key in projectList.list) { 
           	          //element = projList[i].split('|');
           	          projCont += '<option value="' + projectList.list[key].project_id + '">' + projectList.list[key].name + '</option>';
           	          //i++;
                    }
           	        $('#company_list').html(projCont);
           	    }
        });
    }
    
    $('#start').click(function() {
        host = getHost();
        if ($('#company_list').val() > 0) {
            urlStr  = host
                    + '?module=Project&view=start'
                    + '&userid=' + $('#userid').val()
                    + '&projectid=' + $('#company_list').val()
                    + '&comment=' + $('#comment').val()
                    + '&' + new String (Math.random()).substring (2, 11)
                    + '&format=json&callback=?';
                    ;
      
        $.ajax({url: urlStr,
                cache: true,
                dataType: "jsonp",
                success: function(regId){
         	        //if (regId.ok > 0) {
           	        $('#regid').val(regId);
           	        $('#company_list').attr('disabled', 'disabled');
           	        $('#start').attr('disabled', 'disabled');
                    $('#stop').removeAttr('disabled');
                		if (!System.Gadget.docked) {
                      fillStats();
                		}
                	//}
                }
            });
        }
    });

    $('#stop').click(function() {
        host = getHost();
        urlStr  = host
                + '?module=Project&view=stop'
                + '&userid=' + $('#userid').val()
                + '&projectid=' + $('#company_list').val()
                + '&comment=' + $('#comment').val()
                //+ '&id=' + $('#regid').val()
                + '&' + new String (Math.random()).substring (2, 11)
                + '&format=json&callback=?';
                ;
        //$('#debug').val(urlStr);
        $.ajax({url: urlStr,
                cache: true,
                dataType: "jsonp",
                success: function(success){
           	        $('#debug').val(success.ok);
           	        if (success.ok > 0) {
                        $('#company_list').removeAttr('disabled');
                        $('#start').removeAttr('disabled');
               	        $('#stop').attr('disabled', 'disabled');
                        $('#regid').val(0);
                    		if (!System.Gadget.docked) {
                          fillStats();
                    		}
                		}
                }
        });
    });
    
    var oBody = document.body.style;
    oBody.width = '130px';
    oBody.height = '83px';
    

    timeregbackground.style.width = 0;
    timeregbackground.style.height = 0;
    //timeregbackground.src = "url(images/base-docked.png)";
    
    //var gGadgetMode = (System.Gadget !== undefined);

  	// Set initial values needed for dynamic re-sizing of menu and rows
  	g_sBodyHeight = parseInt(document.body.currentStyle.height);
          	
  	//if (gGadgetMode)
  	//{		
    	System.Gadget.settingsUI = "settings.html";
  		System.Gadget.onDock = DockGadget;
  		System.Gadget.onUndock = UndockGadget;
  
  		if (System.Gadget.docked)
  		{
  			DockGadget();
  		}
  		else
  		{
  			UndockGadget();
  		}
  	//}
  	//else
  	//{	
  	//	UndockGadget();
  	//}
////////////////////////////////////////////////////////////////////////////////
//
// Data for gadget in docked state
//
////////////////////////////////////////////////////////////////////////////////
function DockGadget() {
  	var oBody = document.body.style;
  	oBody.width = '130px';
  	oBody.height = '83px';
  
  	$('#message').css({ 'border':'0px solid #990000',
                        'margin':'5px',
                        'width':'120px'});
    
  
  	timeregbackground.style.width = 0;
  	timeregbackground.style.height = 0;
  	timeregbackground.src = "url(images/base-docked.png)";
  
    $('#stats').hide();

}
////////////////////////////////////////////////////////////////////////////////
//
// Data for gadget in undocked state
//
////////////////////////////////////////////////////////////////////////////////
function UndockGadget() {
  	var oBody = document.body.style;
  	oBody.width = '254px';
  	oBody.height = '300px';
  	//oBody.height = (g_sBodyHeight - g_sRowHeight) + (g_sRowCount * g_sRowHeight);
  	
  	$('#message').css({ 'border':'0px solid #990000',
                        'margin':'15px',
                        'margin-top':'100px',
                        'width':'214px'});
  
  	timeregbackground.style.width = 254;
  	timeregbackground.style.height = 300;
  	//timeregbackground.src = "";
  	timeregbackground.src = "url(images/base-undocked-4.png)";
  	
    fillStats();
}

function fillStats() {
  	var currentTime = new Date()
    var month = currentTime.getMonth() + 1
    var day = currentTime.getDate()
    var year = currentTime.getFullYear()
    if (day < 10)
      day = "0" + day
    if (month < 10)
      month = "0" + month
    var today = day + "-" + month + "-" + year;

    host = getHost();
    workingCompany = $('#company_list').val();
    if ($('#stop').attr('disabled')) {
        workingCompany = 0;
    }
    urlStr  = host
            + '?module=Project&view=day_report'
            + '&userid=' + $('#userid').val()
            + '&date=' + today
            + '&working=' + workingCompany
            + '&' + new String (Math.random()).substring (2, 11)
            + '&format=json&callback=?'
            ;
    //$('#debug').val(urlStr);
    $.ajax({url: urlStr,
                cache: true,
                dataType: "jsonp",
                success: function(projectList){
                    //projList = projectList.split(',');
           	        i = 0;
                    projCont = '<table>';
           	        //while (projList[i].project_id != undefined) {
           	        for (key in projectList.list) {
           	          //element = projList[i].split('|');
                      projCont += '<tr><td>' + projectList.list[key].name + '</td><td>' + projectList.list[key].time + '</td></tr>';
           	          //i++;
                    }
                    projCont += '</table>';
                    $('#stats').html(projCont);
                    $('#stats').show();
              }
    });

}

function getActive() {
    //$('#debug').val('check active');
    host = getHost();
    urlStr  = host
            + '?module=Project&view=has_open'
            + '&userid=' + $('#userid').val()
            + '&' + new String (Math.random()).substring (2, 11)
            + '&format=json&callback=?';
    
    //$('#debug').val(urlStr);
        $.ajax({url: urlStr,
                cache: true,
                dataType: "jsonp",
                success: function(item){
                    //var arr = list.split(",");
                    //$('#debug').val('Res: ' + item);
                    if (item.has_open > 0) {
                        //$('#regid').val(arr[0]);
                        //$('#debug').val(item);
                        $('#company_list').selectOptions(item.has_open);
                        $('#company_list').attr('disabled', 'disabled');
                        $('#start').attr('disabled', 'disabled');
                        $('#stop').removeAttr('disabled');
                        if (item.comment) {
                          $('#comment').val(item.comment);
                        }
                    }
                } 
        });

}

function getHost() {
    return 'http://90.184.164.241/timer/ajax.asp';
    //return 'http://192.168.163.128/TimeReg/ajax.asp';
    //return 'http://localhost/takeamess/ajax.php';
    //return 'http://www.citypolarna.se/takeamess/ajax.php';
}

$('#logout').click(function() {
    $('#register').hide();
    $('#stats').hide();
    $('#login').show();
    $('#userid').val(0);
    $('#password').val('Password');
    $('#username').val('Username');
    $('#company_list').selectOptions(0);
    $('#start').removeAttr('disabled');
    $('#stop').attr('disabled', 'disabled');
     $('#comment').val('');
    DockGadget();
});

});

